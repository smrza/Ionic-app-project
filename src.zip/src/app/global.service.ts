import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  public myinput: string = '';
  public precision: boolean = false;
  public precisionValue: number = 2;

  constructor() { }
}

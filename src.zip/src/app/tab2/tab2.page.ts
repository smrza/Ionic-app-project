import { Component } from '@angular/core';
import { HistoryService } from '../api/history.service';
import { HistoryRecord } from '../models/history-record.model';
import { Tab1Page } from '../tab1/tab1.page';
import { RouterModule } from '@angular/router';
import { NavController, NavParams } from '@ionic/angular';
import {Router} from '@angular/router';
import { Tab1PageModule } from '../tab1/tab1.module';
import { GlobalService } from '../global.service'; 

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  historyArray: HistoryRecord[]

  constructor(private historyService: HistoryService, private router: Router, public global: GlobalService) {}

  ionViewWillEnter()
  {
    //console.log('Method ionViewWillEnter was called.');
    this.historyArray = this.historyService.getRecord();
  }

  
  public btnHistoryClicked(text: String)
  {
    this.router.navigateByUrl('/tabs/tab1');
    
    this.global.myinput += text;
  }

  reuseResult: boolean = true
  reuseSteps: boolean = false

  hide() {
    if(this.reuseResult == true){
      this.reuseResult = false;
      this.reuseSteps = true;
    }
    else {
      this.reuseResult = true;
      this.reuseSteps = false;
    }
  }


}

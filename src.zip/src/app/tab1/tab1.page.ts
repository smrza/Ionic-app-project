import { Component } from '@angular/core';
import {CalculationService} from '../api/calculation.service';
import { LoadingController } from '@ionic/angular';
import { HistoryRecord } from '../models/history-record.model';
import { HistoryService } from '../api/history.service';
import { AlertController } from '@ionic/angular';
import { GlobalService } from '../global.service'; 

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  //public myinput:string = ''
  myoutput:string = ''
  mymemory:number = 0
  loadingDialog: any
  simpleKeyboard: boolean = true
  complexKeyboard: boolean = false

  constructor(private translationService: CalculationService, public loadingController: LoadingController, private historyService: HistoryService, private alertCtrl: AlertController, public global: GlobalService) 
  {
  }

  public btnNumber1Clicked():void
  {
        this.global.myinput += "1";
  }
  public btnNumber2Clicked():void
  {
        this.global.myinput += "2";
  }
  public btnNumber3Clicked():void
  {
        this.global.myinput += "3";
  }
  public btnNumber4Clicked():void
  {
        this.global.myinput += "4";
  }
  public btnNumber5Clicked():void
  {
        this.global.myinput += "5";
  }
  public btnNumber6Clicked():void
  {
        this.global.myinput += "6";
  }
  public btnNumber7Clicked():void
  {
        this.global.myinput += "7";
  }
  public btnNumber8Clicked():void
  {
        this.global.myinput += "8";
  }
  public btnNumber9Clicked():void
  {
        this.global.myinput += "9";
  }
  public btnNumber0Clicked():void
  {
        this.global.myinput += "0";
  }
  public btnDotClicked():void
  {
    if(this.global.myinput.length == 0) return;

    if(this.global.myinput.substr(this.global.myinput.length - 1) == '+' || this.global.myinput.substr(this.global.myinput.length - 1) == '-' || this.global.myinput.substr(this.global.myinput.length - 1) == '÷' || this.global.myinput.substr(this.global.myinput.length - 1) == 'x' || this.global.myinput.substr(this.global.myinput.length - 1) == '(' || this.global.myinput.substr(this.global.myinput.length - 1) == ')'){}
    else{
      for (let i = this.global.myinput.length - 1; i >= 0 ; i--) {
        if(this.global.myinput[i] == "+" || this.global.myinput[i] == "-" || this.global.myinput[i] == "x" || this.global.myinput[i] == "÷"){
          break;
        }
        else if(this.global.myinput[i] == "."){
          return;
        }
      }
    }
     this.global.myinput += ".";
  }
  public btnPlusClicked():void
  {
    if(this.global.myinput.substr(this.global.myinput.length - 1) == '-'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "+";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == 'x'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "+";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == '÷'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "+";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == '+'){
    }
    else this.global.myinput += "+";
  }
  public btnMinusClicked():void
  {
    if(this.global.myinput.substr(this.global.myinput.length - 1) == '+'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "-";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == 'x'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "-";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == '÷'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "-";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == '-'){
    }
    else this.global.myinput += "-";
  }
  public btnDivideClicked():void
  {
    if(this.global.myinput.substr(this.global.myinput.length - 1) == '-'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "÷";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == 'x'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "÷";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == '+'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "÷";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == '÷'){
    }
    else this.global.myinput += "÷";
  }
  public btnMultiplyClicked():void
  {
    if(this.global.myinput.substr(this.global.myinput.length - 1) == '-'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "x";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == '÷'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "x";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == '+'){
      this.global.myinput = this.global.myinput.slice(0, -1);;
      this.global.myinput += "x";
    }
    else if(this.global.myinput.substr(this.global.myinput.length - 1) == 'x'){
    }
    else this.global.myinput += "x";
  }
  public btnResetClicked():void
  {
        this.global.myinput = '';
        this.myoutput = '';
  }

 data: string = '';
 error: string = '';

 public btnEqualsClicked():void
 {
   if(this.global.myinput.length >= 1)
   {
     this.presentLoading();
     this.translationService.getCalculation(this.global.myinput, this.global.precisionValue).subscribe(
      data => {
        this.data = JSON.stringify(data);
        this.myoutput = data.toString();
        let record = new HistoryRecord(this.global.myinput, this.myoutput);
        this.global.myinput = '';
        this.historyService.saveRecord(record);
        this.loadingDialog.dismiss();
      },
      err => {
        this.error = `An error occurred, the data could not be retrieved: Status: ${err.status}, Message: ${err.statusText}`;
        this.global.myinput = '';
        this.presentAlertWrongCall(this.error);
        this.loadingDialog.dismiss();
      }
    );
   }
 } 

  public btnRemoveClicked():void
  {
        this.global.myinput = this.global.myinput.slice(0, -1);;
  }

  public btnResetMemoryClicked():void
  {
    this.mymemory = 0;
  }

  public btnAddMemoryClicked():void
  {
    if(this.myoutput.length >= 1)
    {
      this.mymemory = this.mymemory + parseInt(this.myoutput);
    }
    else this.presentAlert();
  }

  public btnSubtractMemoryClicked():void
  {
    if(this.myoutput.length >= 1)
    {
      this.mymemory = this.mymemory - parseInt(this.myoutput);
    }
    else this.presentAlert();
  }

  public btnRecallMemoryClicked():void
  {
        this.global.myinput += this.mymemory;
  }



  public btnLBracketClicked():void
  {
     this.global.myinput += "(";
  }
  public btnRBracketClicked():void
  {
    if(this.global.myinput.length == 0) return;


      for (let i = this.global.myinput.length - 1; i >= 0 ; i--) {
        if(this.global.myinput[i] == "("){
          this.global.myinput += ")";
          break;
        }      
    }
     

  }
  public btnPiClicked():void
  {
    this.global.myinput += "π";
  }
  public btnEClicked():void
  {
    this.global.myinput += "e";
  }
  public btnSinClicked():void
  {
    this.global.myinput += "sin(";
  }
  public btnCosClicked():void
  {
    this.global.myinput += "cos(";

  }
  public btnTanClicked():void
  {
    this.global.myinput += "tan(";
  }
  public btnLogClicked():void
  {
    this.global.myinput += "log(";
  }
  public btnSquareClicked():void
  {
    this.global.myinput += "^";
  }
  public btnSqrtClicked():void
  {
    this.global.myinput += "sqrt(";
  }
  public btnFactClicked():void
  {
    this.global.myinput += "!";
  }
  public btnReverseSquareClicked():void
  {
    this.global.myinput += "^-1";
  }

  async presentLoading()
  {
    this.loadingDialog = await this.loadingController.create(
    {
      message: 'Calculating ...',
    });
    await this.loadingDialog.present();
  }

  async presentAlert() {
    let alert = this.alertCtrl.create({
      header: 'Result empty',
      subHeader: 'Please, fill your result with a value.',
      buttons: ['Dismiss']
    });
    (await alert).present();
  }

  async presentAlertWrongCall(text: string) {
    let alert = this.alertCtrl.create({
      header: 'Error',
      subHeader: text,
      buttons: ['Dismiss']
    });
    (await alert).present();
  }





  hide() {
    if(this.simpleKeyboard == true){
      this.simpleKeyboard = false;
      this.complexKeyboard = true;
    }
    else {
      this.simpleKeyboard = true;
      this.complexKeyboard = false;
    }
  }



} 





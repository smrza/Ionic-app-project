export class HistoryRecord 
{
    inputHistory: String
    outputHistory: String

    constructor(inputHistory: String, outputHistory: String) 
    {
        this.inputHistory = inputHistory;
        this.outputHistory = outputHistory;
    }
}
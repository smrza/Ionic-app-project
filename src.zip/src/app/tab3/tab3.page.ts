import { Component } from '@angular/core';
import { GlobalService } from '../global.service'; 

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  constructor(public global: GlobalService) {}

  slider:number = 5;

  precisionChange(){

    if(this.global.precision == false){
      this.global.precision = true;
      this.global.precisionValue = this.slider;
    }
    else{
      this.global.precision = false;
      this.global.precisionValue = this.slider;
    } 
    

  }

  changeValue(){
    this.global.precisionValue = this.slider;
  }

}
